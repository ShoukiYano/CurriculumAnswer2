// _________________________________触らない_____________________________________
document.getElementById('task1').addEventListener('click', () => {
    const array = [1, 2, 3, 4, 5];
    document.getElementById('result1').textContent = `合計: ${executeTask1(array)}`;
});

document.getElementById('task2').addEventListener('click', () => {
    const str = "JavaScript";
    document.getElementById('result2').textContent = `逆順: ${executeTask2(str)}`;
});

document.getElementById('task3').addEventListener('click', () => {
    const str = "Hello World";
    document.getElementById('result3').textContent = `文字列の長さ: ${executeTask3(str)}`;
});

document.getElementById('task4').addEventListener('click', () => {
    const text = "hello world";
    document.getElementById('result4').textContent = `大文字: ${executeTask4(text)}`;
});

document.getElementById('task5').addEventListener('click', () => {
    const numbers = [1, 2, 3, 4, 5];
    document.getElementById('result5').textContent = executeTask5(numbers).join(', ');
});
// _____________________________________________________________________________



// 問題1: 数字の配列の合計を計算する
function executeTask1(array) {
    let sum = 0;
    // 手順:
    // 1. forループを使って配列の各要素を順に取り出す
    // 2. 各要素をsumに加算する
    // 3. ループが終了したら、sumには配列の合計が格納されている
    
    // 4. 合計を返す
    // 例: return sum;
    return sum;
}

// 問題2: 文字列を逆順に表示する
function executeTask2(str) {
    let reversed = '';
    // 手順:
    // 1. forループを使って文字列の各文字を逆順に取り出す
    // 2. 各文字をreversedに追加する
    // 3. ループが終了したら、reversedには逆順の文字列が格納されている
    
    // 4. 逆順の文字列を返す
    // 例: return reversed;
    return reversed;
}

// 問題3: 文字列の長さを表示する
function executeTask3(str) {
    let length = 0;
    // 手順:
    // 1. forループを使って文字列の各文字を順に取り出す
    // 2. 各文字ごとにlengthをインクリメントする
    // 3. ループが終了したら、lengthには文字列の長さが格納されている
    
    // 4. 長さを返す
    // 例: return length;
    return length;
}

// 問題4: テキストを大文字に変換する
function executeTask4(text) {
    let upperText = '';
    // 手順:
    // 1. forループを使ってテキストの各文字を順に取り出す
    // 2. 各文字を大文字に変換してupperTextに追加する
    // 3. ループが終了したら、upperTextには大文字のテキストが格納されている
    
    // 4. 大文字のテキストを返す
    // 例: return upperText;
    return upperText;
}

// 問題5: 数字が偶数か奇数かを判定する
function executeTask5(numbers) {
    let results = [];
    // 手順:
    // 1. forループを使って配列の各要素を順に取り出す
    // 2. 各要素が偶数か奇数かを判定する
    // 3. 判定結果をresults配列に追加する
    // 4. ループが終了したら、resultsには判定結果が格納されている
    
    // 5. 判定結果を返す
    // 例: return results;
    return results;
}
