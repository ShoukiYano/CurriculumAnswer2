// 問題1: 以下の関数helloを完成させて、「Hello, World!」とコンソールに表示させてください。
function hello1() {
}

// ＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿

// 問題2: 引数nameを受け取り、「Hello, [name]!」とコンソールに表示する関数helloを作成してください。
function hello2(name) {
}

// ＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿

// 問題3: 2つの数値を引数に取り、その和を戻り値として返す関数addを作成してコンソールに表示してください。
function add(a, b) {
}

// ＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿

// 問題4: 引数で受け取った数値に10を加えて返す関数addTenを作成してコンソールに表示してください。
function addTen(number) {
}

// ＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿

// 問題5: 2つの数値を引数に取り、その積と商を返す関数calculateを作成してコンソールに表示してください。
function calculate(a, b) {
}

const results = calculate(10, 2);
console.log("積: " + results[0] + ", 商: " + results[1]); // 「積: 20, 商: 5」が表示される

// ＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿

// 問題6: 引数に数値を受け取り、その数値に5を加えて返す関数addFiveを作成してコンソールに表示してください。
// 引数が与えられない場合は、0をデフォルトの値として使用してコンソールに表示してください。
function addFive(number = 0) {
}

console.log(addFive(10)); // 15が表示される
console.log(addFive()); // 5が表示される（デフォルト引数が使われる）

// ＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿

// 問題7: 関数式を使用して、2つの数値の差を返す関数subtractを作成してコンソールに表示してください。
const subtract = function(a, b) {
};

console.log(subtract(10, 3)); // 7が表示される

// ＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿

// 問題8: アロー関数を使用して、2つの数値の平均値を返す関数averageを作成してコンソールに表示してください。
const average = (a, b) => 

console.log(average(10, 20)); // 15が表示される

// ＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿

// 問題9: 引数で受け取った数値までの合計を返す関数sumをfor文を使用し作成してコンソールに表示してください。
function sum(limit) {
}

console.log(sum(5)); // 1+2+3+4+5 = 15が表示される

// ＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿

// 問題: 引数で受け取った数値が偶数か奇数かを判断し、その結果を文字列で返す関数checkEvenを作成してコンソールに表示してください。
function checkEven(number) {
}

console.log(checkEven(4)); // '偶数'が表示される
console.log(checkEven(5)); // '奇数'が表示される